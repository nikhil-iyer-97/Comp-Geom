var searchData=
[
  ['theta',['theta',['../classpoint.html#af86603723dab362ce3886429a34c0825',1,'point']]]
];
