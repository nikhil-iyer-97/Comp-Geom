var searchData=
[
  ['upper_5fbridge',['upper_bridge',['../convexhull_8cpp.html#ac420ec219403ac799ef9689b6b994dd5',1,'upper_bridge(const vector&lt; point &gt; &amp;points, long double a):&#160;convexhull.cpp'],['../convexhull_8h.html#ac420ec219403ac799ef9689b6b994dd5',1,'upper_bridge(const vector&lt; point &gt; &amp;points, long double a):&#160;convexhull.cpp']]],
  ['upper_5fhull',['upper_hull',['../convexhull_8cpp.html#a1b0c40e47b16c23f5b7a8dadaf271e37',1,'upper_hull(const vector&lt; point &gt; &amp;points, point pmin, point pmax):&#160;convexhull.cpp'],['../convexhull_8h.html#a1b0c40e47b16c23f5b7a8dadaf271e37',1,'upper_hull(const vector&lt; point &gt; &amp;points, point pmin, point pmax):&#160;convexhull.cpp']]]
];
