var searchData=
[
  ['quad',['quad',['../classangle.html#a71c153d29ce076a5129ffffbc4c2f625',1,'angle']]]
];
