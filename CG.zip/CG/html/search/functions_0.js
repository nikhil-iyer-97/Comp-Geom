var searchData=
[
  ['angle',['angle',['../classangle.html#ac12b9232199d6ca1513cfdea61045985',1,'angle::angle(long double)'],['../classangle.html#a5aac33d28cacc993c94185fa73f344d4',1,'angle::angle(long double, long double)']]]
];
