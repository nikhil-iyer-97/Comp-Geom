var searchData=
[
  ['x',['x',['../classangle.html#a11e82940be1ebe6a64019deaf82eeb1e',1,'angle::x()'],['../classpoint.html#abe3b80a8910700fd88235fa77f759ada',1,'point::x()']]]
];
