var searchData=
[
  ['set_5fangle',['set_angle',['../classangle.html#a2a1f4c6ddea73f5dc46f9f509c11d3bf',1,'angle::set_angle(long double)'],['../classangle.html#a77d80415897671694eb8b9f6bc716226',1,'angle::set_angle(long double, long double)']]],
  ['set_5fpoint',['set_point',['../classpoint.html#ad42a365f445a4d0b429443d7e5d80957',1,'point::set_point(long double, long double, long double, long double)'],['../classpoint.html#a6463bf468d355fee35c1fb2ead4eade9',1,'point::set_point(long double, angle)']]],
  ['sort_5fpoints',['sort_points',['../fundamentals_8cpp.html#ae5a9e584c3d345cd610a8a650aac7998',1,'sort_points(RandomAccessIterator f, RandomAccessIterator l, bool pol):&#160;fundamentals.cpp'],['../fundamentals_8h.html#a16365889cf524205e09a733766debcae',1,'sort_points(RandomAccessIterator, RandomAccessIterator, bool pol=false):&#160;fundamentals.cpp']]],
  ['swap',['swap',['../fundamentals_8cpp.html#a2222b58fb4bbac3e9c6eedf2b3ee8e6d',1,'swap(point &amp;p, point &amp;q):&#160;fundamentals.cpp'],['../fundamentals_8h.html#a9196687c07bfec5623011f25b5f8225a',1,'swap(point &amp;, point &amp;):&#160;fundamentals.cpp']]]
];
