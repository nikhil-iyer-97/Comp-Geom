var searchData=
[
  ['kirkpatrick_5fseidel',['kirkpatrick_seidel',['../convexhull_8cpp.html#ab56bc244e8ada6b9e4005c2507b793f5',1,'kirkpatrick_seidel(const vector&lt; point &gt; &amp;points):&#160;convexhull.cpp'],['../convexhull_8h.html#ab56bc244e8ada6b9e4005c2507b793f5',1,'kirkpatrick_seidel(const vector&lt; point &gt; &amp;points):&#160;convexhull.cpp']]]
];
