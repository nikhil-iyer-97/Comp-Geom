var searchData=
[
  ['get_5fpoint_5fcartesian',['get_point_cartesian',['../classpoint.html#a177d9b5e7bcadfcbe43117ea5f8f5efb',1,'point']]],
  ['get_5fpoint_5fpolar',['get_point_polar',['../classpoint.html#abb0e764395c87ace50d3db576cf0ea61',1,'point']]],
  ['get_5fpoint_5funnormalized',['get_point_unnormalized',['../classpoint.html#ae074e0c127b57f7255e78942b3e72aeb',1,'point']]],
  ['get_5fquadrant',['get_quadrant',['../classangle.html#add527bd5ed67b6ad993bc0c74cf28e71',1,'angle']]],
  ['get_5fradius_5fsquared',['get_radius_squared',['../classpoint.html#ad75fb52af06efebe7354deae3d7d8779',1,'point']]],
  ['get_5fratio',['get_ratio',['../classangle.html#a3a464ba59e72c2101554ddb4c545bb7f',1,'angle']]],
  ['get_5ftan',['get_tan',['../classangle.html#abc5c0a478345198a0afdbaf0f3affe0b',1,'angle']]],
  ['get_5fvalue',['get_value',['../classangle.html#a36180714b7eef2d01bad0ca127f59fc5',1,'angle']]],
  ['graham_5fscan',['graham_scan',['../convexhull_8cpp.html#aa03a794a380dca506a669abb7a70d4f6',1,'graham_scan(const vector&lt; point &gt; &amp;pts):&#160;convexhull.cpp'],['../convexhull_8h.html#aa03a794a380dca506a669abb7a70d4f6',1,'graham_scan(const vector&lt; point &gt; &amp;pts):&#160;convexhull.cpp']]]
];
