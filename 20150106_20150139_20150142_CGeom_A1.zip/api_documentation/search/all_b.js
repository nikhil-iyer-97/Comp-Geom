var searchData=
[
  ['r_5fsq',['r_sq',['../classpoint.html#affb0c0abd0556930a5b69fdd305c42d2',1,'point']]]
];
