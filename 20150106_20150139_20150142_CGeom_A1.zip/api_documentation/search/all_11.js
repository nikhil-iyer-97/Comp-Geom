var searchData=
[
  ['y',['y',['../classangle.html#a49810818d3ead5dd4c5373083dd2117b',1,'angle::y()'],['../classpoint.html#a10dc303b92d37dea053af0d45e4d82c2',1,'point::y()']]]
];
