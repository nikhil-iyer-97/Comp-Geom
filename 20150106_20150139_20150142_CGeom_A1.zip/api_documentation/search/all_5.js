var searchData=
[
  ['jarvis_5fmarch',['jarvis_march',['../convexhull_8cpp.html#a3e13c65226b21914f9b5848ad9e2727b',1,'jarvis_march(const vector&lt; point &gt; &amp;points):&#160;convexhull.cpp'],['../convexhull_8h.html#a3e13c65226b21914f9b5848ad9e2727b',1,'jarvis_march(const vector&lt; point &gt; &amp;points):&#160;convexhull.cpp']]]
];
