var searchData=
[
  ['theta',['theta',['../classpoint.html#af86603723dab362ce3886429a34c0825',1,'point']]],
  ['twice_5ftriangle_5fsigned_5farea',['twice_triangle_signed_area',['../fundamentals_8cpp.html#abef61e64707a4c013b3f03e847b394bb',1,'twice_triangle_signed_area(point a, point b, point c):&#160;fundamentals.cpp'],['../fundamentals_8h.html#abef61e64707a4c013b3f03e847b394bb',1,'twice_triangle_signed_area(point a, point b, point c):&#160;fundamentals.cpp']]]
];
